<?php
// Iniciar la sesión
session_start();

// Destruir todas las variables de sesión
$_SESSION = array();

// Si se desea destruir la sesión completamente, también eliminar la cookie de sesión
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Finalmente, destruir la sesión
session_destroy();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Información guardada</title>

    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <div class="flex items-center justify-center h-screen">
        <div class="bg-white shadow-lg rounded-lg p-8 max-w-md text-center">
            <h1 class="text-2xl font-bold text-gray-800 mb-4">Información guardada con éxito</h1>
            <p class="text-gray-600">Gracias por completar el formulario. Su información ha sido guardada exitosamente.</p>
            <p class="mt-4 text-gray-600">Cualquier proceso o duda, comuníquese al correo <a href="mailto:lsantos@cas.edu.gt" class="text-blue-500 underline">lsantos@cas.edu.gt</a>. Nos pondremos en contacto con usted si hay novedades.</p>
        </div>
    </div>
</body>
</html>
