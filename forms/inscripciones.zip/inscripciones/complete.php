<?php
// Iniciar la sesión
session_start();

// Verificar si las variables necesarias están en la sesión
if (isset($_SESSION['nombres_alumno'], $_SESSION['correo_encargado_lleno_f'], $_SESSION['nombre_encargado_lleno_f'])) {

    // Cargar las dependencias de PHPMailer
    require 'path/to/PHPMailer/src/Exception.php';
    require 'path/to/PHPMailer/src/PHPMailer.php';
    require 'path/to/PHPMailer/src/SMTP.php';

    // Obtener los valores de la sesión
    $nombres_alumno = $_SESSION['nombres_alumno'];
    $correo_encargado_lleno_f = $_SESSION['correo_encargado_lleno_f'];
    $nombre_encargado_lleno_f = $_SESSION['nombre_encargado_lleno_f'];

    // Crear una instancia de PHPMailer
    $mail = new PHPMailer\PHPMailer\PHPMailer(true);

    try {
        // Configuración del servidor SMTP
        $mail->isSMTP();
        $mail->Host = 'cas.edu.gt';  // Configura tu servidor SMTP
        $mail->SMTPAuth = true;
        $mail->Username = 'casnursing@cas.edu.gt';  // Configura tu correo
        $mail->Password = 'Cas2024*';  // Configura tu contraseña
        $mail->SMTPSecure = 'ssl';
        $mail->Port = 465;
 
        // Configurar los destinatarios
        $mail->setFrom('casnursing@cas.edu.gt', 'Hesler');
        $mail->addAddress("hlopez@cas.edu.gt", "Hesler");

        // Contenido del correo
        $mail->isHTML(true);
        $mail->Subject = 'Confirmación de envío de datos de ' . $nombres_alumno;
        
        
        $mail->Body    = "<p>Estimado/a <b>$nombre_encargado_lleno_f</b>,</p>
                          <p>Se ha recibido correctamente la información del estudiante <b>$nombres_alumno</b>.
                          ";

        // Enviar el correo
        $mail->send();
    } catch (Exception $e) {
        echo "El mensaje no pudo ser enviado. Error: {$mail->ErrorInfo}";
    }

    // Destruir la sesión una vez que ya no sea necesaria
    session_destroy();
     exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Información guardada</title>
   
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <div class="flex items-center justify-center h-screen">
        <div class="bg-white shadow-lg rounded-lg p-8 max-w-md text-center">
            <h1 class="text-2xl font-bold text-gray-800 mb-4">Información guardada con éxito</h1>
            <p class="text-gray-600">Gracias por completar el formulario. Su información ha sido guardada exitosamente.</p>
            <p class="mt-4 text-gray-600">Cualquier proceso o duda, comuníquese al correo <a href="mailto:lsantos@cas.edu.gt" class="text-blue-500 underline">lsantos@cas.edu.gt</a>. Nos pondremos en contacto con usted si hay novedades.</p>
            
            <!-- Botón de Finalizar -->
            <button onclick="window.location.href='./index.php';" class="mt-6 bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 focus:outline-none">
                Finalizar
            </button>
        </div>
    </div>
</body>
</html>
