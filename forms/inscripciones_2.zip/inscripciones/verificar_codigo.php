<?php
require './conexion.php';
$year = date("Y");

// Verificar si el código fue enviado por POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $codigo = trim($_POST['codigo']);
    $nombres = trim($_POST['new_nombres']);
    $apellidos = trim($_POST['new_apellidos']);
    $email = trim($_POST['new_email']);
    $password = password_hash(trim($_POST['new_password']), PASSWORD_DEFAULT); 

    // Consulta para verificar el código en la tabla "token_usuarios_nuevos"
    $sql = "SELECT codigo FROM token_usuarios_nuevos WHERE codigo = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $codigo);
    $stmt->execute();

    // En lugar de get_result(), usamos bind_result() para obtener el resultado
    $stmt->bind_result($codigo_bd);
    $stmt->fetch();

    if ($codigo_bd) {
        // Liberar el resultado antes de realizar una nueva consulta
        $stmt->free_result();
        $stmt->close();

        // Código válido, ahora generamos el campo "codigo_alumno"
        $primer_nombre = explode(' ', $nombres)[0];
        $primer_apellido = explode(' ', $apellidos)[0];
        $codigo_numerico = rand(10000000, 99999999);
        $codigo_alumno = $primer_nombre . $primer_apellido . $codigo_numerico;
        $estado_nuevo = "1";

        // Insertar en la tabla alumno
        $sql_insert = "INSERT INTO alumno_nuevo_ingreso (nombres_alumno, apellidos_alumno, correo_alumno, pass, codigo_alumno, estado, cicloActual) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt_insert = $conn->prepare($sql_insert);
        $stmt_insert->bind_param("sssssss", $nombres, $apellidos, $email, $password, $codigo_alumno, $estado_nuevo, $year);

        if ($stmt_insert->execute()) {
            // Registro exitoso, redirigir al formulario
            echo "success";
        } else {
            // Error al insertar los datos
            echo "error";
        }

        $stmt_insert->close();
    } else {
        // Código incorrecto
        echo "error";
    }

    $conn->close();
}
?>
