<?php
// Archivo: conexion.php

$servername = "localhost";
$username = "admin_cas_inscr";
$password = "admin_cas_inscr2023";
$dbname = "informacion_estudiantes";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>
