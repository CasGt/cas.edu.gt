<?php
$host = '127.0.0.1';
$dbname = 'casedu_mac';
$username = 'casedug1_inscri';
$password = "c*s2017";

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die('Database connection failed: ' . $conn->connect_error);
}

if (!$conn->set_charset("utf8")) {
    die("Error al establecer la codificació UTF-8: " . $conn->error);
}

?>