<?php
$host = '127.0.0.1';
$dbname = 'informacion_estudiantes';
$username = 'admin_cas_inscr';
$password = 'admin_cas_inscr2023';



$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die('Database connection failed: ' . $conn->connect_error);
}
?>
