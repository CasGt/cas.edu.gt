<?php
include '../../db/connection.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Método no permitido']);
    exit();
}

// Leer el cuerpo de la solicitud
$input = json_decode(file_get_contents('php://input'), true);

// Verificar si hay una acción definida
if (empty($input['action'])) {
    http_response_code(400);
    echo json_encode(['error' => 'No se especificó ninguna acción']);
    exit();
}

$action = $input['action'];

// Manejar las acciones de forma modular
switch ($action) {
    case 'pending':
        handlePending($input, $conn);
        break;

    // Aquí se pueden agregar más acciones en el futuro
    default:
        http_response_code(400);
        echo json_encode(['error' => "La acción '$action' no está soportada"]);
        break;
}

$conn->close();

// Función para manejar la acción `pending`
function handlePending($data, $conn) {
    // Validar campos necesarios
    $required_fields = ['id', 'codigo_alumno', 'updated_at', 'estado'];
    $missing_fields = [];

    foreach ($required_fields as $field) {
        if (empty($data[$field])) {
            $missing_fields[] = $field;
        }
    }

    if (!empty($missing_fields)) {
        http_response_code(400);
        echo json_encode(['error' => 'Faltan campos necesarios', 'missing_fields' => $missing_fields]);
        return;
    }

    // Extraer valores
    $id = intval($data['id']);
    $codigo_alumno = htmlspecialchars(trim($data['codigo_alumno']));
    $updated_at = htmlspecialchars(trim($data['updated_at']));
    $estado = intval($data['estado']); // 1 = Activar, 3 = Eliminar

    if (!in_array($estado, [1, 3])) {
        http_response_code(400);
        echo json_encode(['error' => 'Estado no válido. Debe ser 1 (Activar) o 3 (Eliminar)']);
        return;
    }

    // Actualizar el estado del estudiante
    $query = "UPDATE alumno SET estado = ?, updated_at = ? WHERE id_alumno = ? AND codigo_alumno = ?";
    $stmt = $conn->prepare($query);

    if ($stmt) {
        $stmt->bind_param("isis", $estado, $updated_at, $id, $codigo_alumno);
        if ($stmt->execute()) {
            echo json_encode([
                'message' => $estado === 1 
                    ? 'Estudiante activado correctamente' 
                    : 'Estudiante eliminado correctamente'
            ]);
        } else {
            http_response_code(500);
            echo json_encode(['error' => 'Error al actualizar el estado del estudiante']);
        }
        $stmt->close();
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'Error al preparar la consulta']);
    }
}
