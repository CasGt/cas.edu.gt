<?php
session_start();
include '../shared/role_validation.php';
include '../shared/alerts.php';
require '../../db/connection.php';
validateAccess('medicina');
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Historial Médico - Área de Enfermería</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css">
    <script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
</head>
<body class="bg-blue-50 text-gray-800">

<!-- Navbar -->


<!-- Espaciador para evitar que la tabla se superponga al navbar -->
<div class="mt-16"></div>

<!-- Contenedor Principal -->
<div class="container mx-auto p-6 bg-white rounded-lg shadow-md">
    <h1 class="text-2xl font-bold mb-6 text-gray-700 text-center">Historial Médico</h1>

    <!-- Tabla -->
    <div class="overflow-x-auto">
        <table id="miTabla" class="w-full bg-white border border-gray-300 rounded-lg shadow-md">
            <thead>
                <tr class="bg-blue-100">
                    <th class="text-sm p-2">Carnet</th>
                    <th class="text-sm p-2">Nombres</th>
                    <th class="text-sm p-2">Apellidos</th>
                    <th class="text-sm p-2">Grado</th>
                    <th class="text-sm p-2">Última Visita</th>
                    <th class="text-sm p-2">Ciclo Actual</th>
                    <th class="text-sm p-2">Acción</th>
                </tr>
            </thead>
            <tbody>
                <!-- Filas generadas dinámicamente -->
            </tbody>
        </table>
    </div>
</div>

<!-- Script para Cargar Datos -->
<script>
    document.addEventListener("DOMContentLoaded", () => {
        const tableBody = document.querySelector('#miTabla tbody');

        // Llamada al API
        fetch('../api/get_student.php?action=recent_or_previous')
            .then(response => {
                if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
                return response.json();
            })
            .then(data => {
                if (data.success && data.data.length > 0) {
                    tableBody.innerHTML = '';
                    data.data.forEach(student => {
                        const row = `
                            <tr class="hover:bg-gray-100">
                                <td class="border p-2">${student.carnet || 'N/A'}</td>
                                <td class="border p-2">${student.nombres || 'N/A'}</td>
                                <td class="border p-2">${student.apellidos || 'N/A'}</td>
                                <td class="border p-2">${student.grado || 'N/A'}</td>
                                <td class="border p-2">${student.updated_at || 'N/A'}</td>
                                <td class="border p-2">${student.cicloActual || 'N/A'}</td>
                                <td class="border p-2">
                                    <a href="./medical_history.php?codigo_alumno=${student.codigo_alumno}&ciclo_actual=${student.cicloActual}&carnet=${student.carnet}&nombres=${student.nombres}&apellidos=${student.apellidos}&grado=${student.grado}&fecha=${student.updated_at}" class="text-blue-500 hover:underline">Historial médico</a>
                                </td>
                            </tr>`;
                        tableBody.insertAdjacentHTML('beforeend', row);
                    });

                    // Inicializa DataTables
                    $('#miTabla').DataTable({
                        destroy: true,
                        language: {
                            url: "https://cdn.datatables.net/plug-ins/1.10.25/i18n/Spanish.json"
                        }
                    });
                } else {
                    tableBody.innerHTML = '<tr><td colspan="7" class="text-center text-gray-500 p-4">No se encontraron estudiantes.</td></tr>';
                }
            })
            .catch(error => {
                console.error('Error al obtener los datos:', error);
                tableBody.innerHTML = '<tr><td colspan="7" class="text-center text-red-500 p-4">Error al cargar los datos. Por favor, intente nuevamente.</td></tr>';
            });
    });
</script>

</body>
</html>
