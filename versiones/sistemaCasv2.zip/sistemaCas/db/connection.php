<?php
$host = 'localhost';
$dbname = 'informacion_estudiantes';
$username = 'root';
$password = 'admin';

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die('Database connection failed: ' . $conn->connect_error);
}
?>
