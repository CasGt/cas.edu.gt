<?php
include '../../db/connection.php';

header('Content-Type: application/json');

// Validar si se solicita por `codigo_alumno`
if (isset($_GET['codigo_alumno']) && !empty(trim($_GET['codigo_alumno']))) {
    $codigoAlumno = trim($_GET['codigo_alumno']);

    try {
        // Consulta específica por `codigo_alumno`
        $query = "SELECT 
            id_alumno AS id, 
            carnet, 
            codigo_alumno, 
            nombres_alumno AS nombres, 
            apellidos_alumno AS apellidos, 
            correo_alumno AS correo, 
            grado_alumno AS grado, 
            nacimiento_alumno AS fecha_nacimiento, 
            correo_encargado_llenar_form AS correo_encargado 
        FROM alumno
        WHERE codigo_alumno = ?";

        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $codigoAlumno);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $student = $result->fetch_assoc();
            // Aplicar prefijo G0 solo a grados del 1 al 12
            if (is_numeric($student['grado']) && intval($student['grado']) >= 1 && intval($student['grado']) <= 12) {
                $student['grado'] = 'G0' . $student['grado'];
            }
            echo json_encode(['success' => true, 'data' => $student]);
        } else {
            echo json_encode(['success' => false, 'message' => 'No se encontró el estudiante con el código proporcionado.']);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
} elseif (isset($_GET['action']) && $_GET['action'] === 'pending') {$anio_actual = date("Y");
    $grade = isset($_GET['grade']) ? trim($_GET['grade']) : '';
    $search = isset($_GET['search']) ? trim($_GET['search']) : '';

    try {
        $query = "SELECT 
            alumno.id_alumno AS id, 
            alumno.carnet, 
            alumno.codigo_alumno, 
            alumno.nombres_alumno AS nombres, 
            alumno.apellidos_alumno AS apellidos, 
            alumno.correo_alumno AS correo, 
            alumno.grado_alumno AS grado, 
            alumno.nacimiento_alumno AS fecha_nacimiento, 
            alumno.correo_encargado_llenar_form AS correo_encargado, 
            alumno.updated_at
        FROM alumno
        WHERE alumno.cicloActual = ? AND alumno.estado = 2";

        // Filtro por grado
        if (!empty($grade)) {
            $query .= " AND alumno.grado_alumno = ?";
        }

        // Filtro por búsqueda
        if (!empty($search)) {
            $query .= " AND (alumno.nombres_alumno LIKE ? OR alumno.apellidos_alumno LIKE ? OR alumno.carnet LIKE ?)";
        }

        $stmt = $conn->prepare($query);

        if (!empty($grade) && !empty($search)) {
            $search = '%' . $search . '%';
            $stmt->bind_param("isssss", $anio_actual, $grade, $search, $search, $search);
        } elseif (!empty($grade)) {
            $stmt->bind_param("is", $anio_actual, $grade);
        } elseif (!empty($search)) {
            $search = '%' . $search . '%';
            $stmt->bind_param("isss", $anio_actual, $search, $search, $search);
        } else {
            $stmt->bind_param("i", $anio_actual);
        }

        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $data = [];
            while ($row = $result->fetch_assoc()) {
                // Aplicar prefijo G0 solo a grados del 1 al 12
                if (is_numeric($row['grado']) && intval($row['grado']) >= 1 && intval($row['grado']) <= 12) {
                    $row['grado'] = 'G0' . $row['grado'];
                }
                $data[] = $row;
            }
            echo json_encode(['success' => true, 'data' => $data]);
        } else {
            echo json_encode(['success' => true, 'data' => []]);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
} else {
    // Lógica original para listar estudiantes con filtros
    $year = isset($_GET['year']) ? intval($_GET['year']) : date("Y");
    $status = isset($_GET['status']) ? intval($_GET['status']) : 1;
    $grade = isset($_GET['grade']) ? trim($_GET['grade']) : '';
    $search = isset($_GET['search']) ? trim($_GET['search']) : '';

    try {
        $query = "SELECT 
            id_alumno AS id, 
            carnet, 
            codigo_alumno, 
            nombres_alumno AS nombres, 
            apellidos_alumno AS apellidos, 
            correo_alumno AS correo, 
            grado_alumno AS grado, 
            nacimiento_alumno AS fecha_nacimiento, 
            correo_encargado_llenar_form AS correo_encargado 
        FROM alumno
        WHERE estado = ? AND cicloActual = ?";

        // Agregar filtro de grado si existe
        if (!empty($grade)) {
            $query .= " AND grado_alumno = ?";
        }

        // Agregar búsqueda si existe
        if (!empty($search)) {
            $query .= " AND (nombres_alumno LIKE ? OR apellidos_alumno LIKE ? OR carnet LIKE ?)";
        }

        $stmt = $conn->prepare($query);

        if (!empty($grade) && !empty($search)) {
            $search = '%' . $search . '%';
            $stmt->bind_param("iisssss", $status, $year, $grade, $search, $search, $search);
        } elseif (!empty($grade)) {
            $stmt->bind_param("iis", $status, $year, $grade);
        } elseif (!empty($search)) {
            $search = '%' . $search . '%';
            $stmt->bind_param("iisss", $status, $year, $search, $search, $search);
        } else {
            $stmt->bind_param("ii", $status, $year);
        }

        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $data = [];
            while ($row = $result->fetch_assoc()) {
                // Aplicar prefijo G0 solo a grados del 1 al 12
                if (is_numeric($row['grado']) && intval($row['grado']) >= 1 && intval($row['grado']) <= 12) {
                    $row['grado'] = 'G0' . $row['grado'];
                }
                $data[] = $row;
            }
            echo json_encode(['success' => true, 'data' => $data]);
        } else {
            echo json_encode(['success' => true, 'data' => []]);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
}

$conn->close();
?>
